#ifndef rspa_solve
#define rspa_solve

int solve_sc_spa(SparseConstraints *, double *, double *m, int *, double * );

#endif



