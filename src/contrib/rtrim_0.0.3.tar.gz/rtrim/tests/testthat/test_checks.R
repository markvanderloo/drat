

context("data checkers")

test_that("basic assertions",{
  expect_error(assert_positive(-1,"foo"),regexp = "foo")
  expect_error(assert_positive(0,"foo"),regexp = "foo")
  expect_true(assert_positive(1,"foo"))  

  expect_error(assert_increasing(c(3,1,4)) )
  expect_true(assert_increasing(1:2))
  
  expect_error(assert_sufficient_counts(count=0:2,index = 1:3))
  expect_true(assert_sufficient_counts(count=1:3,index=1:3))
})




test_that("Sufficient data for piecewise linear trend model (Model 2)",{
  d <- data.frame(count=rep(0:10,2), site=rep(1:2,11), time=rep(1:11,each=2))
  expect_true(assert_plt_model(d$count, d$time, changepoints=c(1,4,10)))
  expect_true(assert_plt_model(d$count, d$time, changepoints=integer(0)))
  
  d$count[21:22] <- 0
  expect_error(assert_plt_model(d$count, d$time, changepoints=c(1,4,10)),regexp="10")
})


test_that("Sufficient data for model 3 with covariates",{
  
  d <- data.frame(count = rep(0:1,2), time = rep(1:2,each=2), cov = rep(1:2,2))
  expect_error(assert_covariate_counts(d$count, d$time, d["cov"]),regexp="cov")
  d <- data.frame(count = rep(7:8,2),time = rep(1:2,each=2), cov = rep(1:2,2))
  expect_true(assert_covariate_counts(d$count, d$time, d["cov"]))
  
  # with errors in two covariates
  
  d <- data.frame(count = rep(0:1,2), time = rep(1:2,each=2)
                  , covA = rep(1:2,2)
                  , covB = rep(letters[1:2],2))
  expect_error(assert_covariate_counts(d$count, d$time, d[3:4]),regexp="covB")
  expect_true(assert_covariate_counts(d$count, d$time, data.frame()))
  
  
})
