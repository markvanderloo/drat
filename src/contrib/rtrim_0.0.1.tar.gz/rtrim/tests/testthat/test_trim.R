context("TRIM models without covariates")

test_that("skylark-1d model",{
  tc <- read_tcf("outfiles/skylark-1d.tcf")
  m <- trim(tc)
  to <- read_tof("outfiles/skylark-1d.out")

  # data basics
  expect_equal(m$nsite, get_n_site(to))
  expect_equal(m$ntime, get_n_time(to))
    
  # time index check
  tgt <- get_time_indices(to)
  out <- index(m,"both")
  for ( i in seq_len(ncol(tgt)) ){
    expect_true( max(abs(out[,i]-tgt[,i]), na.rm=TRUE) < 1e-4
      , info=sprintf("Time index column %d",i)
    )
  }
  
  # time totals check
  tgt <- get_time_totals(to)
  out <- totals(m,"both")
  for ( i in seq_len(ncol(tgt)) ){
    expect_true( max(abs(out[,i]-tgt[,i]), na.rm=TRUE) < 1e-4
      , info=sprintf("Time totals column %d",i)
    )
  }
  
  # overall slope
  tgt <- get_overal_imputed_slope(to)
  out <- overall(m,"imputed")
  # std errors are not tested here...
  expect_true( max( abs(out$coef[2,c(1,3)] - tgt[c(1,3)]) ) < 1e-4)
  # but here, with a somewhat higher tolerance:
  expect_true( max( abs(out$coef[2,c(2,4)] - tgt[c(2,4)]) ) < 1e-3)

  # goodness-of-fit
  tgt <- get_gof(to)
  out <- gof(m)
  expect_equal(out$chi2$chi2, tgt$chi2$chi2, tol = 1e-3, info="chi2 value")
  expect_equal(out$chi2$df, tgt$chi2$df, info="chi2 df")
  expect_equal(out$chi2$p, tgt$chi2$p, tol= 1e-5, info="chi2 p-value") 
  expect_equal(out$LR$LR, tgt$LR$LR, tol=1e-3, info="Likelihood ratio")
  expect_equal(out$LR$df, tgt$LR$df,info="Likelihood ratio df")  
  expect_equal(abs(out$AIC), abs(tgt$AIC), tol=1e-4, info="AIC value") 
  
  # wald test
  tgt <- get_wald(to)
  out <- wald(m)
  expect_equal(out$W,tgt$W,tol=1e-3, info="Wald test value")
  expect_equal(out$df,tgt$df, info="Wald test df")
  expect_equal(out$model,tgt$model, info="model type")
  expect_equal(out$p, tgt$p, tol=1e-4, info="Wald test p-value")
  
  # coefficients
  tgt <- get_coef(to)
  out <- coefficients(m)
  
  expect_equal(out$model, tgt$model)
  for ( i in seq_len(ncol(tgt$coef)) ){
    expect_equal(out$coef[,i], tgt$coef[,i], tol=1e-4
       , info=sprintf("Coefficients column %d",i)
   )
  }

})


