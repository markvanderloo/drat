
# compare TRIM model m against trim output string to.
trimtest <- function(m, to, tc){

  # data basics
  expect_equal(m$nsite, get_n_site(to))
  expect_equal(m$ntime, get_n_time(to))

  # Overdispersion and serial correlation
  if (tc$overdisp) expect_true(abs(m$sig2 - get_overdispersion(to)) < 1e3)
  if (tc$serialcor) expect_true(abs(m$rho - get_serial_correlation(to)) < 1e-3)

  # time index check
  tgt <- get_time_indices(to)
  out <- index(m,"both")
  for ( i in seq_len(ncol(tgt)) ){
    expect_true( max(abs(out[,i]-tgt[,i]), na.rm=TRUE) < 1e-4
      , info=sprintf("Time index column %d",i)
    )
  }

  # time totals check
  tgt <- get_time_totals(to)
  out <- totals(m,"both")
  for ( i in seq_len(ncol(tgt)) ){
    expect_true( max(abs(out[,i]-tgt[,i]), na.rm=TRUE) < 1e-4
      , info=sprintf("Time totals column %d",i)
    )
  }

  # overall slope
  tgt <- get_overal_imputed_slope(to)
  out <- overall(m,"imputed")
  # std errors are not tested here...
  expect_true(abs(out$coef[2,1] - tgt[1]) < 1e-4)
  expect_true(abs(out$coef[2,3] - tgt[3]) < 1e-4)


  # but here, with a somewhat higher tolerance:
  expect_true( max( abs(out$coef[2,c(2,4)] - tgt[c(2,4)]) ) < 1e-3)

  # goodness-of-fit
  tgt <- get_gof(to)
  out <- gof(m)
  expect_equal(out$chi2$chi2, tgt$chi2$chi2, tol = 1e-3, info="chi2 value")
  expect_equal(out$chi2$df, tgt$chi2$df, info="chi2 df")
  expect_equal(out$chi2$p, tgt$chi2$p, tol= 1e-4, info="chi2 p-value")
  expect_equal(out$LR$LR, tgt$LR$LR, tol=1e-3, info="Likelihood ratio")
  expect_equal(out$LR$df, tgt$LR$df,info="Likelihood ratio df")
  expect_equal(abs(out$AIC), abs(tgt$AIC), tol=1e-4, info="AIC value")

  # wald test
  tgt <- get_wald(to)
  out <- wald(m)
  if ( !is.null(tgt$dslope) ){
    expect_equal(out$dslope$W, tgt$dslope$W, tol=1e-2)
  }
  if(!is.null(tgt$slope)){
    expect_equal(out$slope$W,tgt$slope$W,tol=1e-2, info="Wald test value")
    expect_true(all(out$slope$df==tgt$slope$df), info="Wald test df")
    expect_equal(out$slope$p, tgt$slope$p, tol=1e-4, info="Wald test p-value")
  }
  if (!is.null(tgt$deviations)){
    expect_equal(out$deviations$W,tgt$deviations$W,1e-2)
    expect_equal(out$deviations$df,tgt$deviations$df)
    expect_equal(out$deviations$p,tgt$deviations$p,1e-4)
  }
  if (!is.null(tgt$covar)){
    expect_equal(out$covar$W,tgt$covar$W,1e-2)
    expect_equal(out$covar$df,tgt$covar$df)
    expect_equal(out$covar$p,tgt$covar$p,1e-4)
  }
  # coefficients
  tgt <- get_coef(to,tc$labels)
  out <- coefficients(m,which="both")
  v <- c("add","se_add","mul","se_mul")
  expect_equal(tgt$add,out$add,tol=1e-4)
  expect_equal(tgt$mul,out$mul,tol=1e-4)
  expect_equal(tgt$se_add,out$se_add,tol=1e-4)
  expect_equal(tgt$se_mul,out$se_mul,tol=1e-4)
  if(!is.null(tgt$from)) expect_equal(tgt$from,out$from)
  if(!is.null(tgt$from)) expect_equal(tgt$upto,out$upto)
  if(!is.null(tgt$time)) expect_equal(tgt$time,out$time)
  if(!is.null(tgt$cat)) expect_equal(tgt$cat,out$cat)
  if(!is.null(tgt$covar)) expect_equal(tgt$covar, as.character(out$covar))
}

context("TRIM Model 3 [vanilla]")

test_that("skylark-1a",{
  tc <- read_tcf("outfiles/skylark-1a.tcf")
  m <- trim(tc)
  to <- read_tof("outfiles/skylark-1a.out")
  trimtest(m, to, tc)
})

context("TRIM Model 3 [overdisp]")

test_that("skylark-1b",{
  tc <- read_tcf("outfiles/skylark-1b.tcf")
  m <- trim(tc)
  to <- read_tof("outfiles/skylark-1b.out")
  trimtest(m, to,tc)
})

context("TRIM Model 3 [overdisp, ser.corr]")

test_that("skylark 1c",{
  tc <- read_tcf("outfiles/skylark-1c.tcf")
  m <- trim(tc)
  to <- read_tof("outfiles/skylark-1c.out")
  trimtest(m, to,tc)
})


context("TRIM Model 2 [overdisp, ser.cor]")

test_that("skylark 1d",{
  tc <- read_tcf("outfiles/skylark-1d.tcf")
  m <- trim(tc)
  to <- read_tof("outfiles/skylark-1d.out")
  trimtest(m, to,tc)
})


context("TRIM Model 2 [overdisp, ser.cor, all ch.points]")

test_that("skylark-1e",{
  tc <- read_tcf("outfiles/skylark-1e.tcf")
  m <- trim(tc)
  to <- read_tof("outfiles/skylark-1e.out")
  trimtest(m,to,tc)
})


context("TRIM Model 2 [overdisp, ser.cor, 2 ch.points]")

test_that("skylark-1f",{
  tc <- read_tcf("outfiles/skylark-1f.tcf")
  m <- trim(tc)
  to <- read_tof("outfiles/skylark-1f.out")
  trimtest(m,to,tc)
})

context("TRIM Model 2 [overdisp, ser.cor, covar, ch.points]")

test_that("skylark-2a",{
  tc <- read_tcf("outfiles/skylark-2a.tcf")
  m <- trim(tc)
  to <- read_tof("outfiles/skylark-2a.out")
  trimtest(m,to,tc)
})

context("TRIM Model 3 [overdisp, ser.cor, covar]")

test_that("skylark-2b",{
  tc <- read_tcf("outfiles/skylark-2b.tcf")
  m <- trim(tc)
  to <- read_tof("outfiles/skylark-2b.out")
  trimtest(m,to,tc)
})

context("TRIM Model 2 [overdisp, ser.cor, covar, stepwise]")

test_that("skylark-3a",{
  tc <- read_tcf("outfiles/skylark-3a.tcf")
  m <- trim(tc)
  to <- read_tof("outfiles/skylark-3a.out")
  trimtest(m,to,tc)
})


context("Output printers")
test_that("S3 output printers", {
  data(skylark)
  m2 <- trim(count ~ time + site, data=skylark, model=2, overdisp=TRUE, serialcor = TRUE)
  expect_output(print(m2))
  expect_output(print(coef(m2)))
  expect_output(print(wald(m2)))
  expect_output(print(overall(m2)))
  expect_output(print(totals(m2)))
  expect_output(print(index(m2)))
})


