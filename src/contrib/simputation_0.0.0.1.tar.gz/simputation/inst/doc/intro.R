## ---- echo=FALSE---------------------------------------------------------
library(simputation)

## ---- eval=FALSE---------------------------------------------------------
#  impute_<model>(data, formula, <optionally, model-specific options>)

## ------------------------------------------------------------------------
dat <- iris
dat[1:3,1] <- dat[3:7,2] <- dat[8:10,5] <- NA
head(dat,10)

## ------------------------------------------------------------------------
da1 <- impute_lm(dat, Sepal.Length ~ Sepal.Width + Species)
head(da1,3)

## ------------------------------------------------------------------------
da2 <- impute_median(da1, Sepal.Length ~ Species)
head(da2,3)

## ------------------------------------------------------------------------
da3 <- impute_cart(da2, Species ~ .)
head(da3,10)

## ---- eval=FALSE---------------------------------------------------------
#  library(magrittr)
#  da4 <- dat %>%
#    impute_lm(Sepal.Length ~ Sepal.Width + Species) %>%
#    impute_median(Sepal.Length ~ Species) %>%
#    impute_cart(Species ~ .)

## ------------------------------------------------------------------------
da5 <- impute_rlm(dat, Sepal.Length + Sepal.Width ~ Petal.Length + Species)
head(da5)

## ------------------------------------------------------------------------
da6 <- impute_lm(dat, . - Species ~ 0 + Species, add_residual = "normal")
head(da6)

