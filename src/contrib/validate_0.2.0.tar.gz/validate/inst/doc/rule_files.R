## ----eval=FALSE----------------------------------------------------------
#  v <- validator(.file="ex-1.txt")

## ---- eval=FALSE---------------------------------------------------------
#  v <- validator(height>0, weight> 0)
#  export_yaml(v,file="my_rules.yaml")

