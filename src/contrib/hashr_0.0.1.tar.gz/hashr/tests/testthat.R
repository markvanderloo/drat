library(testthat)
test_check("hashr")

