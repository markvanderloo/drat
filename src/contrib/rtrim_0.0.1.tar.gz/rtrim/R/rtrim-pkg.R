#' Reimplementation of the TRIM software of Jeroen Pannekoek
#'
#' @name rtrim-package
#' @docType package
#' @import methods
#' @importFrom utils read.table head tail str
#' @importFrom grDevices  gray rgb
#' @importFrom graphics lines plot points polygon segments title
#' @importFrom stats pchisq pt qt time
#'
{}
