#' @name skylark
#' @title Skylark population data
#' 
#' @description 
#' 
#' The Skylark dataset that was included with the original TRIM software.
#' 
#'
#' @docType data
#' @format \code{.RData}
#'
NULL
