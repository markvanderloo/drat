


#' @rdname impute_
#' @export
impute_glm <- function(dat, formula,...){
  d <- dat; m <- formula
  cat("not implemented yet\n")
}

