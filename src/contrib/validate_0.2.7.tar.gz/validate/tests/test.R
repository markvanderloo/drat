

pkg <- "validate"
require("RUnit", quietly=TRUE)
require("validate", quietly=TRUE)

ts <- defineTestSuite(pkg
  , dirs = system.file("RUnit", package=pkg)
  , testFileRegexp = "^test.+\\.[rR]"
  , testFuncRegexp = "^test.+")

tr <- runTestSuite(ts)
printTextProtocol(tr)

