library(testthat)
test_check("deductive")

