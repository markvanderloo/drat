


#' @rdname impute_
#' @export
impute_glm <- function(dat, model,...){
  d <- dat; m <- model
  cat("not implemented yet\n")
}

