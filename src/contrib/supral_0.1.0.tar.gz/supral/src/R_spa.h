
SEXP R_solve_sc_spa(SEXP, SEXP, SEXP, SEXP, SEXP);

