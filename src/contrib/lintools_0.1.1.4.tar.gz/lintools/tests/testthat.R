library(testthat)
test_check("lintools")

