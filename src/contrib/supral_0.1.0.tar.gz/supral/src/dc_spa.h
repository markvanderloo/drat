
#ifndef rspa_dcspa
#define rspa_dcspa


int dc_solve(double *, double *, double *, int, int, int, double *, int *, double *);


#endif



